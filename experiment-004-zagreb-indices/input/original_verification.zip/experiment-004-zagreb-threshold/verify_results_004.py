#!/usr/bin/env python3
"""Recompute certificates and the bounded edge-type relaxation with exact arithmetic.

Python 3.10+, standard library only. Does not trust listed degrees, invariants,
connectivity, or claimed gaps. The enumeration is of necessary edge-type vectors,
NOT an enumeration of all graphs. The report supplies its completeness proof.
"""
from __future__ import annotations
import argparse
from collections import Counter
from fractions import Fraction
from itertools import combinations, combinations_with_replacement
import json
from pathlib import Path
import sys

TYPES = tuple(combinations_with_replacement(range(2, 6), 2))
DEFECTS = tuple(t for t in TYPES if t not in ((2, 5), (3, 3)))

def graph_statistics(n: int, edges: list) -> dict:
    if type(n) is not int or n < 1:
        raise ValueError("n must be a positive integer, not a boolean")
    if not isinstance(edges, list):
        raise ValueError("edges must be a list")
    adjacency = [set() for _ in range(n)]
    seen_edges = set()
    for edge in edges:
        if not isinstance(edge, (list, tuple)) or len(edge) != 2:
            raise ValueError("Each edge must have exactly two endpoints")
        u, v = edge
        if any(type(x) is not int for x in (u, v)):
            raise ValueError("Endpoints must be integers, not booleans")
        if not (0 <= u < n and 0 <= v < n):
            raise ValueError("Endpoint outside [0,n)")
        if u == v:
            raise ValueError("Self-loop")
        key = tuple(sorted((u, v)))
        if key in seen_edges:
            raise ValueError("Duplicate undirected edge")
        seen_edges.add(key)
        adjacency[u].add(v)
        adjacency[v].add(u)
    reached, stack = {0}, [0]
    while stack:
        for v in adjacency[stack.pop()]:
            if v not in reached:
                reached.add(v)
                stack.append(v)
    degrees = [len(a) for a in adjacency]
    histogram = Counter(degrees)
    edge_histogram = Counter(tuple(sorted((degrees[u], degrees[v]))) for u, v in seen_edges)
    m = len(seen_edges)
    M1 = sum(d * d for d in degrees)
    M2 = sum(degrees[u] * degrees[v] for u, v in seen_edges)
    return {
        "n": n, "m": m, "M1": M1, "M2": M2, "gap": m * M1 - n * M2,
        "minimum_degree": min(degrees), "maximum_degree": max(degrees),
        "connected": len(reached) == n,
        "degree_counts": {str(d): histogram[d] for d in sorted(set(range(2, 6)) | set(histogram))},
        "edge_types": {f"{i},{j}": count for (i, j), count in sorted(edge_histogram.items())},
    }

def verify_certificate(certificate: dict) -> dict:
    if not isinstance(certificate, dict) or "n" not in certificate or "edges" not in certificate:
        raise ValueError("A certificate must contain n and edges")
    stats = graph_statistics(certificate["n"], certificate["edges"])
    if not stats["connected"]:
        raise ValueError("Graph is disconnected")
    if (stats["minimum_degree"], stats["maximum_degree"]) != (2, 5):
        raise ValueError("Graph does not have minimum degree 2 and maximum degree 5")
    if stats["gap"] <= 0:
        raise ValueError("Graph is not a counterexample")
    expected = certificate.get("expected", {})
    if not isinstance(expected, dict):
        raise ValueError("expected must be an object")
    for key, value in expected.items():
        if key not in stats or stats[key] != value:
            raise ValueError(f"Metadata mismatch for {key}: computed {stats.get(key)!r}, listed {value!r}")
    return {"id": certificate.get("id", "unnamed"), **stats}

def psi(p: tuple[int, int], q: tuple[int, int]) -> Fraction:
    i, j = p
    k, ell = q
    return (Fraction(i * j, k) + Fraction(i * j, ell)
            + Fraction(k * ell, i) + Fraction(k * ell, j) - i - j - k - ell)

def bounded_vectors(length: int, budget: int):
    """All nonnegative vectors of the given length with coordinate sum <= budget."""
    if length == 1:
        for x in range(budget + 1):
            yield (x,)
        return
    for x in range(budget + 1):
        for rest in bounded_vectors(length - 1, budget - x):
            yield (x,) + rest

def exhaustive_edge_type_check() -> dict:
    """Complete necessary-vector relaxation for counterexamples of order <=46.

    The report proves: a=e25>0, b=e33>0; at most six other edges;
    a<=65 and b<=69. These are mathematical bounds, not heuristic cutoffs.
    Graph realizability is NOT assumed or asserted for enumerated vectors.
    """
    negative_coefficients = [(p, q, psi(p, q)) for p, q in combinations(TYPES, 2) if psi(p, q) < 0]
    if negative_coefficients != [((2, 5), (3, 3), Fraction(-1, 30))]:
        raise RuntimeError("Unexpected coefficient table")
    for t in DEFECTS:
        if psi((2, 5), t) < Fraction(1, 10) or psi((3, 3), t) < Fraction(1, 12):
            raise RuntimeError("Defect-count bound failed")
    patterns = integral = connected_support_count = 0
    counterexample_vectors = []
    for z in bounded_vectors(len(DEFECTS), 6):
        patterns += 1
        stubs = [0] * 6
        for (i, j), multiplicity in zip(DEFECTS, z):
            stubs[i] += multiplicity
            stubs[j] += multiplicity
        if stubs[4] % 4:
            continue
        base_m = sum(z)
        base_M1 = sum((i + j) * v for (i, j), v in zip(DEFECTS, z))
        base_M2 = sum(i * j * v for (i, j), v in zip(DEFECTS, z))
        support = {i: set() for i in range(2, 6)}
        for (i, j), multiplicity in zip(DEFECTS, z):
            if multiplicity:
                support[i].add(j)
                support[j].add(i)
        support[2].add(5)
        support[5].add(2)
        active = {2, 3, 5} | ({4} if stubs[4] else set())
        seen, stack = {2}, [2]
        while stack:
            for j in support[stack.pop()]:
                if j not in seen:
                    seen.add(j)
                    stack.append(j)
        support_connected = seen == active
        for a in range(1, 66):
            if (a + stubs[2]) % 2 or (a + stubs[5]) % 5:
                continue
            n2, n5, n4 = (a + stubs[2]) // 2, (a + stubs[5]) // 5, stubs[4] // 4
            for b in range(1, 70):
                if (2 * b + stubs[3]) % 3:
                    continue
                n3 = (2 * b + stubs[3]) // 3
                n = n2 + n3 + n4 + n5
                if n > 46:
                    continue
                integral += 1
                if not support_connected:
                    continue
                connected_support_count += 1
                m, M1, M2 = a + b + base_m, 7 * a + 6 * b + base_M1, 10 * a + 9 * b + base_M2
                gap = m * M1 - n * M2
                if gap > 0:
                    entries = [((2, 5), a), ((3, 3), b)] + list(zip(DEFECTS, z))
                    counterexample_vectors.append({
                        "n": n, "m": m, "M1": M1, "M2": M2, "gap": gap,
                        "degree_counts": {"2": n2, "3": n3, "4": n4, "5": n5},
                        "edge_types": {f"{i},{j}": v for (i, j), v in sorted(entries) if v},
                    })
    if len(counterexample_vectors) != 1:
        raise RuntimeError("Unexpected number of positive-gap vectors")
    expected = {"n": 46, "m": 67, "M1": 436, "M2": 635, "gap": 2,
                "degree_counts": {"2": 18, "3": 21, "4": 0, "5": 7},
                "edge_types": {"2,3": 1, "2,5": 35, "3,3": 31}}
    if counterexample_vectors[0] != expected:
        raise RuntimeError("Unexpected extremal vector")
    return {"defect_patterns": patterns, "integral_vectors": integral,
            "connected_degree_support_vectors": connected_support_count,
            "counterexample_vectors": counterexample_vectors}

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("certificates", nargs="?", type=Path,
                        default=Path(__file__).with_name("example_certificates.json"))
    parser.add_argument("--exhaustive", action="store_true", help="Also verify the bounded edge-type relaxation")
    parser.add_argument("--output", type=Path, help="Save complete recomputed results as JSON")
    args = parser.parse_args()
    try:
        data = json.loads(args.certificates.read_text(encoding="utf-8"))
        if type(data.get("schema_version")) is not int or data.get("schema_version") != 1:
            raise ValueError("Unsupported certificate schema")
        certificates = data.get("certificates")
        if not isinstance(certificates, list) or not certificates:
            raise ValueError("Expected a nonempty certificates list")
        results = {"certificates": [verify_certificate(c) for c in certificates]}
        if args.exhaustive:
            results["edge_type_enumeration"] = exhaustive_edge_type_check()
        if args.output:
            args.output.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(results, indent=2))
    except (ValueError, OSError, TypeError, RuntimeError, AttributeError) as error:
        print(f"VERIFICATION FAILED: {error}", file=sys.stderr)
        raise SystemExit(1)

if __name__ == "__main__":
    main()
