#!/usr/bin/env python3
"""Optional second implementation using NetworkX and symbolic identities using SymPy.

These libraries are NOT needed by the main verifier. This is an implementation
cross-check in the same investigation, not an independent expert review.
"""
import json
from pathlib import Path
from collections import Counter
import platform
import networkx as nx
import sympy as sp

HERE = Path(__file__).resolve().parent

def main():
    data = json.loads((HERE / "example_certificates.json").read_text())
    results = []
    for certificate in data["certificates"]:
        graph = nx.Graph()
        graph.add_nodes_from(range(certificate["n"]))
        graph.add_edges_from(certificate["edges"])
        degrees = dict(graph.degree())
        n, m = graph.number_of_nodes(), graph.number_of_edges()
        M1 = sum(x**2 for x in degrees.values())
        M2 = sum(degrees[u] * degrees[v] for u, v in graph.edges())
        stats = {"n": n, "m": m, "M1": M1, "M2": M2, "gap": m*M1 - n*M2,
                 "connected": nx.is_connected(graph), "minimum_degree": min(degrees.values()),
                 "maximum_degree": max(degrees.values())}
        for key, value in stats.items():
            if value != certificate["expected"][key]:
                raise RuntimeError(f"Mismatch: {certificate['id']}, {key}")
        if m != len(certificate["edges"]) or nx.number_of_selfloops(graph):
            raise RuntimeError("Input was not simple")
        results.append({"id": certificate["id"], **stats})
    k, ell = sp.symbols("k ell")
    n = (7*k + 4*ell + 3)/2
    m = 5*k + 3*ell + 2
    M1 = 35*k + 18*ell + 11
    M2 = 50*k + 27*ell + 15
    expression = sp.factor(m*M1-n*M2)
    if sp.expand(expression - (k*ell-5*k-3*ell-1)/2) != 0:
        raise RuntimeError("Family identity failed")
    a, b = sp.symbols("a b")
    case1 = sp.expand((a+b+1)*(7*a+6*b+5) - (sp.Rational(7,10)*a+sp.Rational(2,3)*b+sp.Rational(5,6))*(10*a+9*b+6))
    case2 = sp.expand((a+b+4)*(7*a+6*b+25) - (sp.Rational(7,10)*a+sp.Rational(2,3)*b+sp.Rational(17,6))*(10*a+9*b+36))
    target = a*b/30-8*a/15-b/2
    if sp.simplify(case1-target) != 0 or sp.simplify(case2-(target-2)) != 0:
        raise RuntimeError("Minimality case identities failed")
    output = {"python": platform.python_version(), "networkx": nx.__version__, "sympy": sp.__version__,
              "certificates_crosschecked": results,
              "symbolic_family_gap": str(expression), "case1_gap": str(case1), "case2_gap": str(case2),
              "all_checks_passed": True}
    (HERE / "independent_crosscheck_results.json").write_text(json.dumps(output, indent=2)+"\n")
    print(json.dumps(output, indent=2))

if __name__ == "__main__":
    main()
