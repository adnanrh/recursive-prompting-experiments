#!/usr/bin/env python3
"""Adversarial verifier tests and finite regression tests of the infinite family."""
from __future__ import annotations
from copy import deepcopy
from fractions import Fraction
from itertools import combinations
import json
from pathlib import Path
import random
import unittest
from construct_graphs_004 import (build_46, build_family, build_for_order, family_parameters,
                                  make_certificates, predicted_family_statistics)
from verify_results_004 import (TYPES, exhaustive_edge_type_check, graph_statistics,
                                psi, verify_certificate)

class VerifierTests(unittest.TestCase):
    def setUp(self):
        self.certificate = make_certificates()["certificates"][0]

    def test_canonical(self):
        s = verify_certificate(self.certificate)
        self.assertEqual(Fraction(s["M1"], s["n"]) - Fraction(s["M2"], s["m"]), Fraction(1, 1541))

    def reject_mutation(self, mutation):
        c = deepcopy(self.certificate)
        mutation(c)
        with self.assertRaises(ValueError):
            verify_certificate(c)

    def test_self_loop(self):
        self.reject_mutation(lambda c: c["edges"].append([0, 0]))
    def test_duplicate(self):
        self.reject_mutation(lambda c: c["edges"].append(c["edges"][0]))
    def test_reversed_duplicate(self):
        self.reject_mutation(lambda c: c["edges"].append(c["edges"][0][::-1]))
    def test_missing_bridge(self):
        self.reject_mutation(lambda c: c["edges"].remove([24, 45]))
    def test_false_metadata(self):
        self.reject_mutation(lambda c: c["expected"].update({"gap": 3}))
    def test_non_integer(self):
        self.reject_mutation(lambda c: c["edges"].append([0.0, 2]))
    def test_boolean_endpoint(self):
        self.reject_mutation(lambda c: c["edges"].append([True, 2]))
    def test_boolean_order(self):
        self.reject_mutation(lambda c: c.update({"n": True}))
    def test_out_of_range(self):
        self.reject_mutation(lambda c: c["edges"].append([0, c["n"]]))
    def test_negative_endpoint(self):
        self.reject_mutation(lambda c: c["edges"].append([-1, 2]))
    def test_malformed_edge(self):
        self.reject_mutation(lambda c: c["edges"].append([0, 1, 2]))
    def test_not_a_counterexample(self):
        n, edges = build_family(3, 3)
        s = graph_statistics(n, edges)
        self.assertEqual((s["minimum_degree"], s["maximum_degree"]), (2, 5))
        self.assertLessEqual(s["gap"], 0)
        with self.assertRaises(ValueError):
            verify_certificate({"n": n, "edges": edges})
    def test_invalid_parameters(self):
        for k, ell in ((2, 10), (4, 10), (7, 2), (True, 10)):
            with self.assertRaises(ValueError):
                build_family(k, ell)
    def test_exhaustive_relaxation(self):
        s = exhaustive_edge_type_check()
        self.assertEqual((s["defect_patterns"], s["integral_vectors"],
                          s["connected_degree_support_vectors"]), (3003, 49380, 36641))
    def test_quadratic_identity(self):
        rng = random.Random(20261109)
        for _ in range(1000):
            e = {t: rng.randrange(8) for t in TYPES}
            m = sum(e.values())
            n = sum((Fraction(1, i) + Fraction(1, j)) * e[(i, j)] for i, j in TYPES)
            M1 = sum((i + j) * e[(i, j)] for i, j in TYPES)
            M2 = sum(i * j * e[(i, j)] for i, j in TYPES)
            kernel = -sum(psi(t, u) * e[t] * e[u] for t, u in combinations(TYPES, 2))
            self.assertEqual(m * M1 - n * M2, kernel)
    def test_general_family_parameters(self):
        for k in range(3, 32, 2):
            for ell in range(3, 32):
                n, edges = build_family(k, ell)
                self.assertEqual(graph_statistics(n, edges), predicted_family_statistics(k, ell))
    def test_every_order_46_to_1000_and_two_large_orders(self):
        orders = list(range(46, 1001)) + [10000, 10001]
        for order in orders:
            k, ell = family_parameters(order)
            n, edges = build_for_order(order)
            s = verify_certificate({"n": n, "edges": edges,
                                    "expected": predicted_family_statistics(k, ell)})
            self.assertEqual(s["n"], order)
            self.assertEqual(s["gap"], order - 44 if order % 2 == 0 else (order - 45) // 2)

if __name__ == "__main__":
    unittest.main(verbosity=2)
