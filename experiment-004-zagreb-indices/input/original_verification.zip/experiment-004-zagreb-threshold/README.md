# Experiment 004 — The Zagreb threshold is 45

Reproducibility bundle for a proposed solution to Question I in Ali Ghalavand,
*On a Conjecture about Comparing the First and Second Zagreb Indices of Graphs*,
MATCH 96 (2026), 441–452, DOI 10.46793/match.96-2.04725.

For finite connected simple graphs with minimum degree 2 and maximum degree 5,
the proposed theorem proves that the first counterexample to M1/n <= M2/m has
46 vertices, classifies its edge-type counts, and constructs examples at every
order n >= 46. The historical unrestricted conjecture was already disproved.

**Unrefereed research.** Code checks do not establish priority or replace review
of the mathematical proof. The separate report contains the complete proof.

## Run the checks

Python 3.10+; no third-party dependencies for the main checks. Run in this folder:

```sh
python verify_results_004.py example_certificates.json --exhaustive
python test_verifier_004.py
```

Expected: seven valid certificates; 3,003 defect patterns; 49,380 integral
edge-type vectors; 36,641 vectors with connected degree-class support; exactly
one positive-gap vector up to order 46, with n=46, m=67, M1=436, M2=635, gap=2.
The test suite has 18 test methods.

To regenerate certificates or save fresh verification results:

```sh
python construct_graphs_004.py
python verify_results_004.py --exhaustive --output fresh_results.json
```

## Contents

- `construct_graphs_004.py`: explicit 46-vertex witness and all-orders family.
- `verify_results_004.py`: structural, arithmetic, and bounded edge-type checks.
- `test_verifier_004.py`: adversarial and regression tests.
- `example_certificates.json`: seven labeled graphs with expected statistics.
- `verification_results.json`: actual exact-arithmetic output from this run.
- `test_results.txt`: actual output of the test suite.
- `independent_crosscheck_004.py`: optional NetworkX/SymPy second implementation.
- `independent_crosscheck_results.json`: actual second-implementation results.
- `SHA256SUMS`: hashes of the files in this bundle, excluding this hash list.

The optional cross-check requires NetworkX and SymPy and runs with:

```sh
python independent_crosscheck_004.py
```

It was tested with Python 3.13.5, NetworkX 3.6.1, and SymPy 1.14.0.
"Independent" in the filename means a separate computational implementation,
not an external mathematician, separate research group, or formal verifier.

## Important interpretation

The bounded search enumerates edge-type count vectors, **not all graphs**.
Its completeness uses the proved six-defect-edge bound in the report.
Degree-class connectivity is necessary but not sufficient for realizability;
retaining impossible vectors is a safe relaxation. The mathematical proof is
self-contained and does not depend on this enumeration.

Each certificate uses vertices 0 through n-1. An edge is an unordered pair.
The verifier rejects loops, repeated/reversed edges, invalid endpoints,
disconnected graphs, wrong minimum/maximum degrees, nonpositive gaps, and
incorrect expected statistics. All arithmetic deciding a violation is exact.

The finite family sweep is a regression test, not the basis of the assertion
for infinitely many orders. That assertion follows from the construction and
closed-form gap proved in the report.

The kernel identity and general approach have prior literature; only the
threshold, extremal profile, and particular all-orders result are proposed as
new. No claim is made to solve the separate counting question (Question II).
