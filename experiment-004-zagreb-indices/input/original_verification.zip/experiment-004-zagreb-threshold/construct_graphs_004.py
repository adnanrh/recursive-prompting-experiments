#!/usr/bin/env python3
"""Deterministic Zagreb counterexample constructions; Python 3.10+, standard library.

The intermediate multigraph in build_family is subdivided edge by edge. The
returned graph is a SIMPLE graph: separate parallel edges get separate vertices.
No graph-library dependency and no numerical optimization is used.
"""
from __future__ import annotations
import argparse
import json
from itertools import combinations
from pathlib import Path

Edge = tuple[int, int]

def _integer(value: int, name: str, minimum: int) -> None:
    if type(value) is not int or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")

def _assemble(k: int, hub_edges: list[Edge], ell: int) -> tuple[int, list[list[int]]]:
    """Subdivide the hub multigraph, add a pendant, and join to a subdivided prism."""
    edges: list[Edge] = []
    next_vertex = k
    for a, b in hub_edges:
        if a == b or not (0 <= a < k and 0 <= b < k):
            raise ValueError("Invalid hub edge")
        edges.extend(((a, next_vertex), (b, next_vertex)))
        next_vertex += 1
    u = next_vertex
    edges.append((0, u))
    offset = u + 1
    # Two ell-cycles and their matching form the cubic prism C_ell x K_2.
    prism: list[Edge] = []
    for layer in range(2):
        for i in range(ell):
            prism.append((offset + layer * ell + i,
                          offset + layer * ell + (i + 1) % ell))
    prism.extend((offset + i, offset + ell + i) for i in range(ell))
    w = offset + 2 * ell
    removed = prism.pop(0)
    edges.extend(prism)
    edges.extend(((removed[0], w), (removed[1], w), (u, w)))
    # Do not silently deduplicate: the verifier must catch any construction bug.
    return w + 1, [list(e) for e in sorted(tuple(sorted(e)) for e in edges)]

def build_46() -> tuple[int, list[list[int]]]:
    """K7 minus {01,02,34,56}, fully subdivided, joined to a subdivided 10-prism."""
    removed = {(0, 1), (0, 2), (3, 4), (5, 6)}
    hubs = [e for e in combinations(range(7), 2) if e not in removed]
    return _assemble(7, hubs, 10)

def build_family(k: int, ell: int) -> tuple[int, list[list[int]]]:
    _integer(k, "k", 3)
    _integer(ell, "ell", 3)
    if k % 2 == 0:
        raise ValueError("k must be odd")
    hubs: list[Edge] = []
    for i in range(k):
        hubs.extend([(i, (i + 1) % k)] * 2)
    hubs.extend((i, i + 1) for i in range(1, k, 2))
    return _assemble(k, hubs, ell)

def family_parameters(n: int) -> tuple[int, int]:
    _integer(n, "n", 46)
    return (7, (n - 26) // 2) if n % 2 == 0 else (5, (n - 19) // 2)

def build_for_order(n: int) -> tuple[int, list[list[int]]]:
    return build_family(*family_parameters(n))

def predicted_family_statistics(k: int, ell: int) -> dict:
    """Closed forms, intentionally not calculated by inspecting the edge list."""
    return {
        "n": (7 * k + 4 * ell + 3) // 2,
        "m": 5 * k + 3 * ell + 2,
        "M1": 35 * k + 18 * ell + 11,
        "M2": 50 * k + 27 * ell + 15,
        "gap": (k * ell - 5 * k - 3 * ell - 1) // 2,
        "minimum_degree": 2, "maximum_degree": 5, "connected": True,
        "degree_counts": {"2": (5 * k + 1) // 2, "3": 2 * ell + 1, "4": 0, "5": k},
        "edge_types": {"2,3": 1, "2,5": 5 * k, "3,3": 3 * ell + 1},
    }

def make_certificates() -> dict:
    n, edges = build_46()
    certificates = [{
        "id": "canonical_46_K7_minus_four_edges",
        "construction": {"kind": "canonical_46", "bridge": [24, 45]},
        "n": n, "edges": edges,
        "expected": {
            "n": 46, "m": 67, "M1": 436, "M2": 635, "gap": 2,
            "minimum_degree": 2, "maximum_degree": 5, "connected": True,
            "degree_counts": {"2": 18, "3": 21, "4": 0, "5": 7},
            "edge_types": {"2,3": 1, "2,5": 35, "3,3": 31},
        },
    }]
    for order in (46, 47, 48, 49, 100, 101):
        k, ell = family_parameters(order)
        n, edges = build_family(k, ell)
        certificates.append({
            "id": f"family_{order}", "construction": {"kind": "family", "k": k, "ell": ell},
            "n": n, "edges": edges, "expected": predicted_family_statistics(k, ell),
        })
    return {"schema_version": 1, "certificates": certificates}

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("example_certificates.json"))
    args = parser.parse_args()
    args.output.write_text(json.dumps(make_certificates(), indent=2) + "\n", encoding="utf-8")
    print(f"Wrote 7 certificates to {args.output}")

if __name__ == "__main__":
    main()
